﻿using System.ComponentModel.DataAnnotations;
namespace GeldeParkEt_Deneme.Models
{
    public class ParkYeri
    {
        [Key]
        public int Id { get; set; }
        [Required]
        public string SlotNumarasi { get; set; } = string.Empty;
        [Required]
        public string Lokasyon { get; set; } = string.Empty;
        public bool IsActive { get; set; } = true; // Otoparkı açıp kapatmaya yarar
        public ICollection<Rezervasyon> Rezervasyonlar { get; set; } = new List<Rezervasyon>();
    }
}