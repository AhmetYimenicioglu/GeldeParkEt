﻿using System.ComponentModel.DataAnnotations;

namespace GeldeParkEt_Deneme.Models
{
    public class Rezervasyon
    {
        [Key]
        public int Id { get; set; }
        public int KullaniciId { get; set; }
        public Kullanici? Kullanici { get; set; }
        public int ParkYeriId { get; set; }
        public ParkYeri? ParkYeri { get; set; }
        public DateTime BaslangicZamani { get; set; }
        public DateTime BitisZamani { get; set; }
        public string Plaka { get; set; } = string.Empty;
        public decimal Ucret { get; set; }
        public string OdemeDurumu { get; set; } = "Odendi";
        public string? DestekMesaji { get; set; }
        public string? AdminCevabi { get; set; }
        public string? UygulamaAnket { get; set; }
        public string? OtoparkAnket { get; set; }
        public decimal CezaTutari { get; set; } = 0;
        public decimal UygulananIndirim { get; set; } = 0;
    }
}