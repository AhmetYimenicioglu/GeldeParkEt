﻿namespace GeldeParkEt_Deneme.Models
{
    public class ParkHaritasiViewModel
    {
        public string SeciliLokasyon { get; set; } = string.Empty;
        public List<ParkYeriDurumViewModel> ParkYerleriDurum { get; set; } = [];
    }

    public class ParkYeriDurumViewModel
    {
        public int Id { get; set; }
        public string SlotNumarasi { get; set; } = string.Empty;
        public bool SuAnRezerveMi { get; set; }

        // YENİ ALANLAR (Hataları çözen kısımlar)
        public bool IsActive { get; set; }
        public string DolulukBilgisi { get; set; } = string.Empty;
    }
}