﻿using System.ComponentModel.DataAnnotations;

namespace GeldeParkEt_Deneme.Models
{
    public class Kullanici
    {
        [Key]
        public int Id { get; set; }

        public string AdSoyad { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public string ParolaHash { get; set; } = string.Empty;
        public string Rol { get; set; } = "User";

        public ICollection<Rezervasyon> Rezervasyonlar { get; set; } = new List<Rezervasyon>();
    }
}