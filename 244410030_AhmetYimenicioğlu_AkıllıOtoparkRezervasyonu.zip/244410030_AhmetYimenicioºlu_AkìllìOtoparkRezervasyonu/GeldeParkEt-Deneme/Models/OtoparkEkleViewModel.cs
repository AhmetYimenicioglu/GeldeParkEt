﻿public class OtoparkEkleViewModel
{
    public string OtoparkAdi { get; set; } // Örn: Meydan AVM Otoparkı
    public int KatSayisi { get; set; }     // Örn: 3
    public int KatBasiSlot { get; set; }   // Örn: 10
}