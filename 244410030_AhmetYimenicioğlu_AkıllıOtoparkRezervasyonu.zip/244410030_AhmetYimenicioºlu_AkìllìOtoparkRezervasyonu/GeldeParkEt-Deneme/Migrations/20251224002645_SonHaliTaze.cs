﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace GeldeParkEt_Deneme.Migrations
{
    /// <inheritdoc />
    public partial class SonHaliTaze : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Kullanicilar",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    AdSoyad = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Email = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ParolaHash = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Rol = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Kullanicilar", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "ParkYerleri",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    SlotNumarasi = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Lokasyon = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ParkYerleri", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Rezervasyonlar",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    KullaniciId = table.Column<int>(type: "int", nullable: false),
                    ParkYeriId = table.Column<int>(type: "int", nullable: false),
                    BaslangicZamani = table.Column<DateTime>(type: "datetime2", nullable: false),
                    BitisZamani = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Plaka = table.Column<string>(type: "nvarchar(10)", maxLength: 10, nullable: false),
                    Ucret = table.Column<decimal>(type: "decimal(18,2)", precision: 18, scale: 2, nullable: false),
                    CezaTutari = table.Column<decimal>(type: "decimal(18,2)", precision: 18, scale: 2, nullable: false),
                    OdemeDurumu = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    DestekMesaji = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    AdminCevabi = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Rezervasyonlar", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Rezervasyonlar_Kullanicilar_KullaniciId",
                        column: x => x.KullaniciId,
                        principalTable: "Kullanicilar",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Rezervasyonlar_ParkYerleri_ParkYeriId",
                        column: x => x.ParkYeriId,
                        principalTable: "ParkYerleri",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.InsertData(
                table: "Kullanicilar",
                columns: new[] { "Id", "AdSoyad", "Email", "ParolaHash", "Rol" },
                values: new object[] { 1, "IT Destek Admin", "admin@otopark.com", "123456", "Admin" });

            migrationBuilder.InsertData(
                table: "ParkYerleri",
                columns: new[] { "Id", "Lokasyon", "SlotNumarasi" },
                values: new object[,]
                {
                    { 2, "Kastamonu", "Zemin - P1" },
                    { 3, "Kastamonu", "Zemin - P2" },
                    { 4, "Kastamonu", "Zemin - P3" },
                    { 5, "Kastamonu", "Zemin - P4" },
                    { 6, "Kastamonu", "Zemin - P5" },
                    { 7, "Kastamonu", "Zemin - P6" },
                    { 8, "Kastamonu", "Zemin - P7" },
                    { 9, "Kastamonu", "Zemin - P8" },
                    { 10, "Kastamonu", "Zemin - P9" },
                    { 11, "Kastamonu", "Zemin - P10" },
                    { 12, "Kastamonu", "Zemin - P11" },
                    { 13, "Kastamonu", "Zemin - P12" },
                    { 14, "Kastamonu", "Zemin - P13" },
                    { 15, "Kastamonu", "Zemin - P14" },
                    { 16, "Kastamonu", "Zemin - P15" },
                    { 17, "Kastamonu", "Zemin - P16" },
                    { 18, "Kastamonu", "Zemin - P17" },
                    { 19, "Kastamonu", "Zemin - P18" },
                    { 20, "Kastamonu", "Zemin - P19" },
                    { 21, "Kastamonu", "Zemin - P20" },
                    { 22, "Tosya", "Zemin - P1" },
                    { 23, "Tosya", "Zemin - P2" },
                    { 24, "Tosya", "Zemin - P3" },
                    { 25, "Tosya", "Zemin - P4" },
                    { 26, "Tosya", "Zemin - P5" },
                    { 27, "Tosya", "Zemin - P6" },
                    { 28, "Tosya", "Zemin - P7" },
                    { 29, "Tosya", "Zemin - P8" },
                    { 30, "Tosya", "Zemin - P9" },
                    { 31, "Tosya", "Zemin - P10" },
                    { 32, "Tosya", "Zemin - P11" },
                    { 33, "Tosya", "Zemin - P12" },
                    { 34, "Tosya", "Zemin - P13" },
                    { 35, "Tosya", "Zemin - P14" },
                    { 36, "Tosya", "Zemin - P15" },
                    { 37, "Tosya", "1. Kat - P1" },
                    { 38, "Tosya", "1. Kat - P2" },
                    { 39, "Tosya", "1. Kat - P3" },
                    { 40, "Tosya", "1. Kat - P4" },
                    { 41, "Tosya", "1. Kat - P5" },
                    { 42, "Tosya", "1. Kat - P6" },
                    { 43, "Tosya", "1. Kat - P7" },
                    { 44, "Tosya", "1. Kat - P8" },
                    { 45, "Tosya", "1. Kat - P9" },
                    { 46, "Tosya", "1. Kat - P10" },
                    { 47, "Tosya", "1. Kat - P11" },
                    { 48, "Tosya", "1. Kat - P12" },
                    { 49, "Tosya", "1. Kat - P13" },
                    { 50, "Tosya", "1. Kat - P14" },
                    { 51, "Tosya", "1. Kat - P15" },
                    { 52, "Tosya", "2. Kat - P1" },
                    { 53, "Tosya", "2. Kat - P2" },
                    { 54, "Tosya", "2. Kat - P3" },
                    { 55, "Tosya", "2. Kat - P4" },
                    { 56, "Tosya", "2. Kat - P5" },
                    { 57, "Tosya", "2. Kat - P6" },
                    { 58, "Tosya", "2. Kat - P7" },
                    { 59, "Tosya", "2. Kat - P8" },
                    { 60, "Tosya", "2. Kat - P9" },
                    { 61, "Tosya", "2. Kat - P10" },
                    { 62, "Tosya", "2. Kat - P11" },
                    { 63, "Tosya", "2. Kat - P12" },
                    { 64, "Tosya", "2. Kat - P13" },
                    { 65, "Tosya", "2. Kat - P14" },
                    { 66, "Tosya", "2. Kat - P15" },
                    { 67, "Bornova", "Zemin - P1" },
                    { 68, "Bornova", "Zemin - P2" },
                    { 69, "Bornova", "Zemin - P3" },
                    { 70, "Bornova", "Zemin - P4" },
                    { 71, "Bornova", "Zemin - P5" },
                    { 72, "Bornova", "Zemin - P6" },
                    { 73, "Bornova", "Zemin - P7" },
                    { 74, "Bornova", "Zemin - P8" },
                    { 75, "Bornova", "Zemin - P9" },
                    { 76, "Bornova", "Zemin - P10" },
                    { 77, "Bornova", "Zemin - P11" },
                    { 78, "Bornova", "Zemin - P12" },
                    { 79, "Bornova", "Zemin - P13" },
                    { 80, "Bornova", "Zemin - P14" },
                    { 81, "Bornova", "Zemin - P15" },
                    { 82, "Bornova", "Zemin - P16" },
                    { 83, "Bornova", "Zemin - P17" },
                    { 84, "Bornova", "Zemin - P18" },
                    { 85, "Bornova", "Zemin - P19" },
                    { 86, "Bornova", "Zemin - P20" },
                    { 87, "Bornova", "Zemin - P21" },
                    { 88, "Bornova", "Zemin - P22" },
                    { 89, "Bornova", "Zemin - P23" },
                    { 90, "Bornova", "Zemin - P24" },
                    { 91, "Bornova", "Zemin - P25" },
                    { 92, "Bornova", "Zemin - P26" },
                    { 93, "Bornova", "Zemin - P27" },
                    { 94, "Bornova", "Zemin - P28" },
                    { 95, "Bornova", "Zemin - P29" },
                    { 96, "Bornova", "Zemin - P30" },
                    { 97, "Bornova", "1. Kat - P1" },
                    { 98, "Bornova", "1. Kat - P2" },
                    { 99, "Bornova", "1. Kat - P3" },
                    { 100, "Bornova", "1. Kat - P4" },
                    { 101, "Bornova", "1. Kat - P5" },
                    { 102, "Bornova", "1. Kat - P6" },
                    { 103, "Bornova", "1. Kat - P7" },
                    { 104, "Bornova", "1. Kat - P8" },
                    { 105, "Bornova", "1. Kat - P9" },
                    { 106, "Bornova", "1. Kat - P10" },
                    { 107, "Bornova", "1. Kat - P11" },
                    { 108, "Bornova", "1. Kat - P12" },
                    { 109, "Bornova", "1. Kat - P13" },
                    { 110, "Bornova", "1. Kat - P14" },
                    { 111, "Bornova", "1. Kat - P15" },
                    { 112, "Bornova", "1. Kat - P16" },
                    { 113, "Bornova", "1. Kat - P17" },
                    { 114, "Bornova", "1. Kat - P18" },
                    { 115, "Bornova", "1. Kat - P19" },
                    { 116, "Bornova", "1. Kat - P20" },
                    { 117, "Bornova", "1. Kat - P21" },
                    { 118, "Bornova", "1. Kat - P22" },
                    { 119, "Bornova", "1. Kat - P23" },
                    { 120, "Bornova", "1. Kat - P24" },
                    { 121, "Bornova", "1. Kat - P25" },
                    { 122, "Bornova", "1. Kat - P26" },
                    { 123, "Bornova", "1. Kat - P27" },
                    { 124, "Bornova", "1. Kat - P28" },
                    { 125, "Bornova", "1. Kat - P29" },
                    { 126, "Bornova", "1. Kat - P30" },
                    { 127, "Bornova", "2. Kat - P1" },
                    { 128, "Bornova", "2. Kat - P2" },
                    { 129, "Bornova", "2. Kat - P3" },
                    { 130, "Bornova", "2. Kat - P4" },
                    { 131, "Bornova", "2. Kat - P5" },
                    { 132, "Bornova", "2. Kat - P6" },
                    { 133, "Bornova", "2. Kat - P7" },
                    { 134, "Bornova", "2. Kat - P8" },
                    { 135, "Bornova", "2. Kat - P9" },
                    { 136, "Bornova", "2. Kat - P10" },
                    { 137, "Bornova", "2. Kat - P11" },
                    { 138, "Bornova", "2. Kat - P12" },
                    { 139, "Bornova", "2. Kat - P13" },
                    { 140, "Bornova", "2. Kat - P14" },
                    { 141, "Bornova", "2. Kat - P15" },
                    { 142, "Bornova", "2. Kat - P16" },
                    { 143, "Bornova", "2. Kat - P17" },
                    { 144, "Bornova", "2. Kat - P18" },
                    { 145, "Bornova", "2. Kat - P19" },
                    { 146, "Bornova", "2. Kat - P20" },
                    { 147, "Bornova", "2. Kat - P21" },
                    { 148, "Bornova", "2. Kat - P22" },
                    { 149, "Bornova", "2. Kat - P23" },
                    { 150, "Bornova", "2. Kat - P24" },
                    { 151, "Bornova", "2. Kat - P25" },
                    { 152, "Bornova", "2. Kat - P26" },
                    { 153, "Bornova", "2. Kat - P27" },
                    { 154, "Bornova", "2. Kat - P28" },
                    { 155, "Bornova", "2. Kat - P29" },
                    { 156, "Bornova", "2. Kat - P30" },
                    { 157, "Bornova", "3. Kat - P1" },
                    { 158, "Bornova", "3. Kat - P2" },
                    { 159, "Bornova", "3. Kat - P3" },
                    { 160, "Bornova", "3. Kat - P4" },
                    { 161, "Bornova", "3. Kat - P5" },
                    { 162, "Bornova", "3. Kat - P6" },
                    { 163, "Bornova", "3. Kat - P7" },
                    { 164, "Bornova", "3. Kat - P8" },
                    { 165, "Bornova", "3. Kat - P9" },
                    { 166, "Bornova", "3. Kat - P10" },
                    { 167, "Bornova", "3. Kat - P11" },
                    { 168, "Bornova", "3. Kat - P12" },
                    { 169, "Bornova", "3. Kat - P13" },
                    { 170, "Bornova", "3. Kat - P14" },
                    { 171, "Bornova", "3. Kat - P15" },
                    { 172, "Bornova", "3. Kat - P16" },
                    { 173, "Bornova", "3. Kat - P17" },
                    { 174, "Bornova", "3. Kat - P18" },
                    { 175, "Bornova", "3. Kat - P19" },
                    { 176, "Bornova", "3. Kat - P20" },
                    { 177, "Bornova", "3. Kat - P21" },
                    { 178, "Bornova", "3. Kat - P22" },
                    { 179, "Bornova", "3. Kat - P23" },
                    { 180, "Bornova", "3. Kat - P24" },
                    { 181, "Bornova", "3. Kat - P25" },
                    { 182, "Bornova", "3. Kat - P26" },
                    { 183, "Bornova", "3. Kat - P27" },
                    { 184, "Bornova", "3. Kat - P28" },
                    { 185, "Bornova", "3. Kat - P29" },
                    { 186, "Bornova", "3. Kat - P30" },
                    { 187, "Bornova", "4. Kat - P1" },
                    { 188, "Bornova", "4. Kat - P2" },
                    { 189, "Bornova", "4. Kat - P3" },
                    { 190, "Bornova", "4. Kat - P4" },
                    { 191, "Bornova", "4. Kat - P5" },
                    { 192, "Bornova", "4. Kat - P6" },
                    { 193, "Bornova", "4. Kat - P7" },
                    { 194, "Bornova", "4. Kat - P8" },
                    { 195, "Bornova", "4. Kat - P9" },
                    { 196, "Bornova", "4. Kat - P10" },
                    { 197, "Bornova", "4. Kat - P11" },
                    { 198, "Bornova", "4. Kat - P12" },
                    { 199, "Bornova", "4. Kat - P13" },
                    { 200, "Bornova", "4. Kat - P14" },
                    { 201, "Bornova", "4. Kat - P15" },
                    { 202, "Bornova", "4. Kat - P16" },
                    { 203, "Bornova", "4. Kat - P17" },
                    { 204, "Bornova", "4. Kat - P18" },
                    { 205, "Bornova", "4. Kat - P19" },
                    { 206, "Bornova", "4. Kat - P20" },
                    { 207, "Bornova", "4. Kat - P21" },
                    { 208, "Bornova", "4. Kat - P22" },
                    { 209, "Bornova", "4. Kat - P23" },
                    { 210, "Bornova", "4. Kat - P24" },
                    { 211, "Bornova", "4. Kat - P25" },
                    { 212, "Bornova", "4. Kat - P26" },
                    { 213, "Bornova", "4. Kat - P27" },
                    { 214, "Bornova", "4. Kat - P28" },
                    { 215, "Bornova", "4. Kat - P29" },
                    { 216, "Bornova", "4. Kat - P30" },
                    { 217, "Bornova", "5. Kat - P1" },
                    { 218, "Bornova", "5. Kat - P2" },
                    { 219, "Bornova", "5. Kat - P3" },
                    { 220, "Bornova", "5. Kat - P4" },
                    { 221, "Bornova", "5. Kat - P5" },
                    { 222, "Bornova", "5. Kat - P6" },
                    { 223, "Bornova", "5. Kat - P7" },
                    { 224, "Bornova", "5. Kat - P8" },
                    { 225, "Bornova", "5. Kat - P9" },
                    { 226, "Bornova", "5. Kat - P10" },
                    { 227, "Bornova", "5. Kat - P11" },
                    { 228, "Bornova", "5. Kat - P12" },
                    { 229, "Bornova", "5. Kat - P13" },
                    { 230, "Bornova", "5. Kat - P14" },
                    { 231, "Bornova", "5. Kat - P15" },
                    { 232, "Bornova", "5. Kat - P16" },
                    { 233, "Bornova", "5. Kat - P17" },
                    { 234, "Bornova", "5. Kat - P18" },
                    { 235, "Bornova", "5. Kat - P19" },
                    { 236, "Bornova", "5. Kat - P20" },
                    { 237, "Bornova", "5. Kat - P21" },
                    { 238, "Bornova", "5. Kat - P22" },
                    { 239, "Bornova", "5. Kat - P23" },
                    { 240, "Bornova", "5. Kat - P24" },
                    { 241, "Bornova", "5. Kat - P25" },
                    { 242, "Bornova", "5. Kat - P26" },
                    { 243, "Bornova", "5. Kat - P27" },
                    { 244, "Bornova", "5. Kat - P28" },
                    { 245, "Bornova", "5. Kat - P29" },
                    { 246, "Bornova", "5. Kat - P30" },
                    { 247, "Üniversite", "Zemin - P1" },
                    { 248, "Üniversite", "Zemin - P2" },
                    { 249, "Üniversite", "Zemin - P3" },
                    { 250, "Üniversite", "Zemin - P4" },
                    { 251, "Üniversite", "Zemin - P5" },
                    { 252, "Üniversite", "Zemin - P6" },
                    { 253, "Üniversite", "Zemin - P7" },
                    { 254, "Üniversite", "Zemin - P8" },
                    { 255, "Üniversite", "1. Kat - P1" },
                    { 256, "Üniversite", "1. Kat - P2" },
                    { 257, "Üniversite", "1. Kat - P3" },
                    { 258, "Üniversite", "1. Kat - P4" },
                    { 259, "Üniversite", "1. Kat - P5" },
                    { 260, "Üniversite", "1. Kat - P6" },
                    { 261, "Üniversite", "1. Kat - P7" },
                    { 262, "Üniversite", "1. Kat - P8" },
                    { 263, "Üniversite", "2. Kat - P1" },
                    { 264, "Üniversite", "2. Kat - P2" },
                    { 265, "Üniversite", "2. Kat - P3" },
                    { 266, "Üniversite", "2. Kat - P4" },
                    { 267, "Üniversite", "2. Kat - P5" },
                    { 268, "Üniversite", "2. Kat - P6" },
                    { 269, "Üniversite", "2. Kat - P7" },
                    { 270, "Üniversite", "2. Kat - P8" },
                    { 271, "Üniversite", "3. Kat - P1" },
                    { 272, "Üniversite", "3. Kat - P2" },
                    { 273, "Üniversite", "3. Kat - P3" },
                    { 274, "Üniversite", "3. Kat - P4" },
                    { 275, "Üniversite", "3. Kat - P5" },
                    { 276, "Üniversite", "3. Kat - P6" },
                    { 277, "Üniversite", "3. Kat - P7" },
                    { 278, "Üniversite", "3. Kat - P8" }
                });

            migrationBuilder.CreateIndex(
                name: "IX_Rezervasyonlar_KullaniciId",
                table: "Rezervasyonlar",
                column: "KullaniciId");

            migrationBuilder.CreateIndex(
                name: "IX_Rezervasyonlar_ParkYeriId",
                table: "Rezervasyonlar",
                column: "ParkYeriId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Rezervasyonlar");

            migrationBuilder.DropTable(
                name: "Kullanicilar");

            migrationBuilder.DropTable(
                name: "ParkYerleri");
        }
    }
}
