using GeldeParkEt_Deneme.Data;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// --- SERV�SLER� EKLEME (Services) ---

// 1. SQL Server ve Entity Framework Core Servisi
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

// 2. Cookie Tabanl� Kimlik Do�rulama Servisi
builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(options =>
    {
        options.LoginPath = "/Account/Login";
        options.AccessDeniedPath = "/Account/AccessDenied";
        options.ExpireTimeSpan = TimeSpan.FromMinutes(30);
    });

// --- YEN�: SESSION (OTURUM) SERV�S� ---
builder.Services.AddDistributedMemoryCache(); // Haf�za y�netimini sa�lar
builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromMinutes(20); // 20 dakika sonra oturum d��er
    options.Cookie.HttpOnly = true;
    options.Cookie.IsEssential = true; // KVKK/GDPR i�in gerekli izni sa�lar
});
// --------------------------------------

builder.Services.AddControllersWithViews();

var app = builder.Build();

// --- HTTP �STEK ��LEM HATTINI YAPILANDIRMA (Middleware) ---

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

// --- YEN�: SESSION KULLANIMI ---
// �nemli: UseRouting'den sonra, UseAuthentication'dan �nce olmal�!
app.UseSession();
// ------------------------------

app.UseAuthentication();
app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Parking}/{action=Index}/{id?}");

app.Run();