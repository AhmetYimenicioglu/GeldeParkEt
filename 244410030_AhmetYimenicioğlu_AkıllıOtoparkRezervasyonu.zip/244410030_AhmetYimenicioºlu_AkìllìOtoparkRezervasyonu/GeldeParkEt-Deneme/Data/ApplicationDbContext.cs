﻿using GeldeParkEt_Deneme.Models;
using Microsoft.EntityFrameworkCore;

namespace GeldeParkEt_Deneme.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }

        public DbSet<Kullanici> Kullanicilar { get; set; }
        public DbSet<ParkYeri> ParkYerleri { get; set; }
        public DbSet<Rezervasyon> Rezervasyonlar { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Rezervasyon>().Property(r => r.Ucret).HasPrecision(18, 2);
            modelBuilder.Entity<Rezervasyon>().Property(r => r.CezaTutari).HasPrecision(18, 2);

            // ADMIN HESABI (admin@otopark.com / 123456)
            modelBuilder.Entity<Kullanici>().HasData(new Kullanici
            {
                Id = 1,
                AdSoyad = "IT Destek Admin",
                Email = "admin@otopark.com",
                ParolaHash = "123456",
                Rol = "Admin"
            });

            // SENİN VERDİĞİN ÖZEL PLANLAR
            var parkYerleri = new List<ParkYeri>();
            int idCounter = 2;

            var otoparkPlanlari = new[]
            {
                new { Isim = "Kastamonu", Katlar = 0, Slotlar = 20 }, // Zemin (20)
                new { Isim = "Tosya", Katlar = 2, Slotlar = 15 },     // Zemin+1+2 (45)
                new { Isim = "Bornova", Katlar = 5, Slotlar = 30 },   // Zemin+5 Kat (180)
                new { Isim = "Üniversite", Katlar = 3, Slotlar = 8 }  // Zemin+3 Kat (32)
            };

            foreach (var plan in otoparkPlanlari)
            {
                for (int k = 0; k <= plan.Katlar; k++)
                {
                    for (int s = 1; s <= plan.Slotlar; s++)
                    {
                        parkYerleri.Add(new ParkYeri
                        {
                            Id = idCounter++,
                            Lokasyon = plan.Isim,
                            SlotNumarasi = (k == 0 ? "Zemin" : $"{k}. Kat") + $" - P{s}"
                        });
                    }
                }
            }
            modelBuilder.Entity<ParkYeri>().HasData(parkYerleri);
        }
    }
}