﻿using GeldeParkEt_Deneme.Data;
using GeldeParkEt_Deneme.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;

namespace GeldeParkEt_Deneme.Controllers
{
    [Authorize(Roles = "User,Admin")]
    public class ParkingController(ApplicationDbContext context) : Controller
    {
        private readonly ApplicationDbContext _context = context;

        public async Task<IActionResult> Index(string lokasyon = "Bornova", DateTime? Baslangic = null, DateTime? Bitis = null)
        {
            DateTime start = Baslangic ?? DateTime.Now;
            DateTime end = Bitis ?? start.AddHours(2);

            var parkYerleri = await _context.ParkYerleri
                .Where(p => p.Lokasyon == lokasyon)
                .OrderBy(p => p.Id).ToListAsync();

            var cakisanRezervasyonlar = await _context.Rezervasyonlar
                .Include(r => r.ParkYeri)
                .Where(r => r.ParkYeri!.Lokasyon == lokasyon &&
                            r.BaslangicZamani < end &&
                            r.BitisZamani > start &&
                            r.OdemeDurumu != "IadeEdildi")
                .ToListAsync();

            var model = new ParkHaritasiViewModel
            {
                SeciliLokasyon = lokasyon,
                ParkYerleriDurum = parkYerleri.Select(p => {
                    var rez = cakisanRezervasyonlar.FirstOrDefault(r => r.ParkYeriId == p.Id);
                    return new ParkYeriDurumViewModel
                    {
                        Id = p.Id,
                        SlotNumarasi = p.SlotNumarasi,
                        IsActive = p.IsActive,
                        SuAnRezerveMi = rez != null,
                        DolulukBilgisi = rez != null ? $"{rez.BaslangicZamani:HH:mm}-{rez.BitisZamani:HH:mm}" : ""
                    };
                }).ToList()
            };

            ViewBag.Start = start.ToString("yyyy-MM-dd HH:mm");
            ViewBag.End = end.ToString("yyyy-MM-dd HH:mm");
            ViewBag.Lokasyonlar = await _context.ParkYerleri.Select(p => p.Lokasyon).Distinct().ToListAsync();

            return View(model);
        }

        [HttpPost]
        public async Task<IActionResult> ProcessToPayment(int ParkYeriId, DateTime Baslangic, DateTime Bitis, string Plaka)
        {
            decimal saatlikUcret = 100m;
            decimal hamUcret = (decimal)Math.Max(1, Math.Ceiling((Bitis - Baslangic).TotalHours)) * saatlikUcret;

            var userIdStr = User.FindFirstValue(ClaimTypes.NameIdentifier);
            bool ilkRezervasyonMu = !await _context.Rezervasyonlar.AnyAsync(r => r.KullaniciId == int.Parse(userIdStr!));

            ViewBag.IlkKayitIndirimi = ilkRezervasyonMu ? 100m : 0m;
            ViewBag.HamUcret = hamUcret;
            ViewBag.ParkYeriId = ParkYeriId;
            ViewBag.Baslangic = Baslangic;
            ViewBag.Bitis = Bitis;
            ViewBag.Plaka = Plaka;

            return View("Payment");
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CompletePayment(int ParkYeriId, DateTime Baslangic, DateTime Bitis, string Plaka, decimal Ucret, decimal Indirim)
        {
            var userIdStr = User.FindFirstValue(ClaimTypes.NameIdentifier);
            if (string.IsNullOrEmpty(userIdStr)) return RedirectToAction("Login", "Account");

            var yeniRezervasyon = new Rezervasyon
            {
                KullaniciId = int.Parse(userIdStr),
                ParkYeriId = ParkYeriId,
                BaslangicZamani = Baslangic,
                BitisZamani = Bitis,
                Plaka = Plaka.ToUpper(),
                Ucret = Ucret,
                UygulananIndirim = Indirim,
                OdemeDurumu = "Odendi"
            };

            _context.Rezervasyonlar.Add(yeniRezervasyon);
            await _context.SaveChangesAsync();

            TempData["SuccessMessage"] = "Rezervasyon başarıyla oluşturuldu!";
            return RedirectToAction("History");
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> SendSupportMessage(int id, string message, string UygulamaAnket, string OtoparkAnket)
        {
            var rez = await _context.Rezervasyonlar.FindAsync(id);
            if (rez != null)
            {
                rez.DestekMesaji = message;
                rez.UygulamaAnket = UygulamaAnket;
                rez.OtoparkAnket = OtoparkAnket;
                await _context.SaveChangesAsync();
                TempData["SuccessMessage"] = "Mesajınız iletildi.";
            }
            return RedirectToAction("History");
        }

        [HttpPost]
        [Authorize(Roles = "Admin")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> HandleSupport(int id, string adminCevabi, string actionType)
        {
            var r = await _context.Rezervasyonlar.FindAsync(id);
            if (r != null)
            {
                r.AdminCevabi = adminCevabi;
                if (actionType == "Refund")
                {
                    r.Ucret = 0;
                    r.OdemeDurumu = "IadeEdildi";
                }
                await _context.SaveChangesAsync();
            }
            return RedirectToAction("AdminPanel");
        }

        public IActionResult Welcome() => View();

        public async Task<IActionResult> History()
        {
            var userIdStr = User.FindFirstValue(ClaimTypes.NameIdentifier);
            if (string.IsNullOrEmpty(userIdStr)) return RedirectToAction("Login", "Account");
            int userId = int.Parse(userIdStr);
            var reservations = await _context.Rezervasyonlar
                .Include(r => r.ParkYeri)
                .Where(r => r.KullaniciId == userId)
                .OrderByDescending(r => r.Id).ToListAsync();
            return View(reservations);
        }

        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> AdminPanel()
        {
            var otoparklar = await _context.ParkYerleri
                .GroupBy(p => p.Lokasyon)
                .Select(g => new { Lok = g.Key, Aktif = g.FirstOrDefault() != null && g.FirstOrDefault()!.IsActive })
                .ToListAsync();

            ViewBag.OtoparkDurumlari = otoparklar.ToDictionary(x => x.Lok, x => x.Aktif);
            var tumRezervasyonlar = await _context.Rezervasyonlar.Include(r => r.Kullanici).Include(r => r.ParkYeri).OrderByDescending(r => r.Id).ToListAsync();
            return View(tumRezervasyonlar);
        }
    }
}