﻿using GeldeParkEt_Deneme.Data;
using GeldeParkEt_Deneme.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace GeldeParkEt_Deneme.Controllers
{
    [Authorize(Roles = "Admin")]
    public class AdminController : Controller
    {
        private readonly ApplicationDbContext _context;
        public AdminController(ApplicationDbContext context) { _context = context; }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ToggleStatus(string lokasyonAdi)
        {
            var yerler = await _context.ParkYerleri.Where(p => p.Lokasyon == lokasyonAdi).ToListAsync();
            if (yerler.Count > 0)
            {
                bool suAnkiDurum = yerler[0].IsActive;
                foreach (var yer in yerler) { yer.IsActive = !suAnkiDurum; }
                await _context.SaveChangesAsync();
                TempData["SuccessMessage"] = $"Otopark {(suAnkiDurum ? "KAPATILDI" : "AÇILDI")}.";
            }
            return RedirectToAction("AdminPanel", "Parking");
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteLocation(string lokasyonAdi)
        {
            var slotIdleri = await _context.ParkYerleri.Where(p => p.Lokasyon == lokasyonAdi).Select(p => p.Id).ToListAsync();
            var bagliRezervasyonlar = await _context.Rezervasyonlar.Where(r => slotIdleri.Contains(r.ParkYeriId)).ToListAsync();

            _context.Rezervasyonlar.RemoveRange(bagliRezervasyonlar);
            var silinecekYerler = await _context.ParkYerleri.Where(p => p.Lokasyon == lokasyonAdi).ToListAsync();
            _context.ParkYerleri.RemoveRange(silinecekYerler);

            await _context.SaveChangesAsync();
            TempData["SuccessMessage"] = $"{lokasyonAdi} tamamen silindi.";
            return RedirectToAction("AdminPanel", "Parking");
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ResetSystem()
        {
            _context.Rezervasyonlar.RemoveRange(_context.Rezervasyonlar);
            _context.ParkYerleri.RemoveRange(_context.ParkYerleri);
            _context.Kullanicilar.RemoveRange(_context.Kullanicilar.Where(u => u.Rol != "Admin"));
            await _context.SaveChangesAsync();
            return RedirectToAction("AdminPanel", "Parking");
        }

        [HttpGet]
        public IActionResult CreateLocation() => View();

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CreateLocation(string lokasyonAdi, int katSayisi, int katBasiSlot)
        {
            var yeniParkYerleri = new List<ParkYeri>();
            for (int i = 0; i <= katSayisi; i++)
            {
                string katIsmi = (i == 0) ? "Zemin" : $"{i}. Kat";
                for (int j = 1; j <= katBasiSlot; j++)
                {
                    yeniParkYerleri.Add(new ParkYeri { Lokasyon = lokasyonAdi, SlotNumarasi = $"{katIsmi} - {j:D2}", IsActive = true });
                }
            }
            await _context.ParkYerleri.AddRangeAsync(yeniParkYerleri);
            await _context.SaveChangesAsync();
            return RedirectToAction("AdminPanel", "Parking");
        }
    }
}