﻿using GeldeParkEt_Deneme.Data;
using GeldeParkEt_Deneme.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;

public class AccountController : Controller
{
    private readonly ApplicationDbContext _context;
    public AccountController(ApplicationDbContext context) { _context = context; }

    [HttpGet]
    public IActionResult Register() => View();

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Register(Kullanici model)
    {
        if (ModelState.IsValid)
        {
            if (string.IsNullOrEmpty(model.Email) || !model.Email.ToLower().EndsWith("@otopark.com"))
            {
                ModelState.AddModelError("Email", "Sadece @otopark.com uzantılı kurumsal mailler kabul edilmektedir.");
                return View(model);
            }

            if (await _context.Kullanicilar.AnyAsync(u => u.Email == model.Email))
            {
                ModelState.AddModelError("Email", "Bu e-posta adresi zaten kayıtlı.");
                return View(model);
            }

            var newUser = new Kullanici
            {
                AdSoyad = model.AdSoyad,
                Email = model.Email.ToLower(),
                ParolaHash = model.ParolaHash,
                Rol = "User"
            };

            _context.Add(newUser);
            await _context.SaveChangesAsync();
            return RedirectToAction("Login");
        }
        return View(model);
    }

    [HttpGet]
    public IActionResult Login()
    {
        // CAPTCHA: Rastgele iki sayı üret ve Session'da sakla
        Random rnd = new Random();
        int s1 = rnd.Next(1, 10);
        int s2 = rnd.Next(1, 10);
        HttpContext.Session.SetInt32("CaptchaSonuc", s1 + s2);

        ViewBag.CaptchaSoru = $"{s1} + {s2} = ?";
        return View();
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Login(string email, string parola, int captchaInput)
    {
        // CAPTCHA KONTROLÜ
        int? dogruSonuc = HttpContext.Session.GetInt32("CaptchaSonuc");
        if (captchaInput != dogruSonuc)
        {
            ModelState.AddModelError(string.Empty, "Güvenlik doğrulaması (CAPTCHA) hatalı.");
            // Hata durumunda soruyu yenile
            return Login();
        }

        var user = await _context.Kullanicilar.FirstOrDefaultAsync(u => u.Email == email);
        if (user != null && user.ParolaHash == parola)
        {
            var claims = new List<Claim> {
                new Claim(ClaimTypes.NameIdentifier, user.Id.ToString()),
                new Claim(ClaimTypes.Name, user.AdSoyad),
                new Claim(ClaimTypes.Role, user.Rol)
            };
            var claimsIdentity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
            await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, new ClaimsPrincipal(claimsIdentity));
            return RedirectToAction("Welcome", "Parking");
        }

        ModelState.AddModelError(string.Empty, "Geçersiz e-posta veya parola.");
        return Login(); // Bilgiler yanlışsa soruyu yenileyerek döner
    }

    public async Task<IActionResult> Logout()
    {
        await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
        return RedirectToAction("Login", "Account");
    }
}