﻿using System.ComponentModel.DataAnnotations;

namespace GeldeParkEt_Deneme.Models
{
    public class OtoparkEkleViewModel
    {
        [Required(ErrorMessage = "Otopark adı zorunludur.")]
        [Display(Name = "Otopark Adı")]
        public string OtoparkAdi { get; set; } = string.Empty;

        [Range(0, 20, ErrorMessage = "Kat sayısı 0 ile 20 arasında olmalıdır.")]
        [Display(Name = "Kat Sayısı (0 = Sadece Zemin)")]
        public int KatSayisi { get; set; } = 0;

        [Range(1, 100, ErrorMessage = "Kat başı slot 1 ile 100 arasında olmalıdır.")]
        [Display(Name = "Kat Başına Slot Sayısı")]
        public int KatBasiSlot { get; set; } = 15;
    }
}