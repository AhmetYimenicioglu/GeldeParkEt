﻿namespace GeldeParkEt_Deneme.Models
{
    public class ParkHaritasiViewModel
    {
        public string SeciliLokasyon { get; set; } = string.Empty;
        public List<ParkYeriDurumViewModel> ParkYerleriDurum { get; set; } = [];

        // Akıllı Otopark İstatistikleri
        public int ToplamSlot => ParkYerleriDurum.Count;
        public int BosSlot => ParkYerleriDurum.Count(p => p.IsActive && !p.SuAnRezerveMi);
        public int DoluSlot => ParkYerleriDurum.Count(p => p.IsActive && p.SuAnRezerveMi);
        public int KapaliSlot => ParkYerleriDurum.Count(p => !p.IsActive);
        public int DolulukOrani => ToplamSlot > 0 ? (int)Math.Round((double)DoluSlot / (ToplamSlot - KapaliSlot > 0 ? ToplamSlot - KapaliSlot : 1) * 100) : 0;
        public string OnerilenKat { get; set; } = "Zemin";
    }

    public class ParkYeriDurumViewModel
    {
        public int Id { get; set; }
        public string SlotNumarasi { get; set; } = string.Empty;
        public bool SuAnRezerveMi { get; set; }
        public bool IsActive { get; set; } = true;
        public string DolulukBilgisi { get; set; } = string.Empty;
    }
}