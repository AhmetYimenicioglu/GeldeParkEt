﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GeldeParkEt_Deneme.Models
{
    public class Rezervasyon
    {
        [Key]
        public int Id { get; set; }

        public int KullaniciId { get; set; }
        public Kullanici? Kullanici { get; set; }

        public int ParkYeriId { get; set; }
        public ParkYeri? ParkYeri { get; set; }

        [Required]
        [Display(Name = "Giriş Zamanı")]
        public DateTime BaslangicZamani { get; set; }

        [Required]
        [Display(Name = "Çıkış Zamanı")]
        public DateTime BitisZamani { get; set; }

        [Required]
        [Display(Name = "Araç Plakası")]
        public string Plaka { get; set; } = string.Empty;

        [Column(TypeName = "decimal(18,2)")]
        [Display(Name = "Ücret")]
        public decimal Ucret { get; set; }

        [Display(Name = "Ödeme Durumu")]
        public string OdemeDurumu { get; set; } = "Odendi"; // "Odendi", "IadeEdildi", "Iptal"

        public string? DestekMesaji { get; set; }
        public string? AdminCevabi { get; set; }
        public string? UygulamaAnket { get; set; }
        public string? OtoparkAnket { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal CezaTutari { get; set; } = 0;

        [Column(TypeName = "decimal(18,2)")]
        public decimal UygulananIndirim { get; set; } = 0;
    }
}