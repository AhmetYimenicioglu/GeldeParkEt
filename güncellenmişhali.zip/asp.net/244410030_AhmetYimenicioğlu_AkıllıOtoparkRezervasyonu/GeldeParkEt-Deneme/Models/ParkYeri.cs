﻿using System.ComponentModel.DataAnnotations;

namespace GeldeParkEt_Deneme.Models
{
    public class ParkYeri
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [Display(Name = "Slot Numarası")]
        public string SlotNumarasi { get; set; } = string.Empty;

        [Required]
        [Display(Name = "Lokasyon")]
        public string Lokasyon { get; set; } = string.Empty;

        [Display(Name = "Aktiflik Durumu")]
        public bool IsActive { get; set; } = true; // Otopark slotunu açıp kapatmaya yarar

        public ICollection<Rezervasyon> Rezervasyonlar { get; set; } = new List<Rezervasyon>();
    }
}