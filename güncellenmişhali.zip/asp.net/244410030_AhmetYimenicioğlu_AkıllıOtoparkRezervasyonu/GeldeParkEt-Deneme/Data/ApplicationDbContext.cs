﻿using GeldeParkEt_Deneme.Models;
using Microsoft.EntityFrameworkCore;

namespace GeldeParkEt_Deneme.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }

        public DbSet<Kullanici> Kullanicilar { get; set; }
        public DbSet<ParkYeri> ParkYerleri { get; set; }
        public DbSet<Rezervasyon> Rezervasyonlar { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Rezervasyon>().Property(r => r.Ucret).HasPrecision(18, 2);
            modelBuilder.Entity<Rezervasyon>().Property(r => r.CezaTutari).HasPrecision(18, 2);
            modelBuilder.Entity<Rezervasyon>().Property(r => r.UygulananIndirim).HasPrecision(18, 2);

            // 1. KULLANICILAR (Seed Data)
            modelBuilder.Entity<Kullanici>().HasData(
                new Kullanici
                {
                    Id = 1,
                    AdSoyad = "Ahmet Yimenicioğlu (Yönetici)",
                    Email = "admin@otopark.com",
                    ParolaHash = "123456",
                    Rol = "Admin"
                },
                new Kullanici
                {
                    Id = 2,
                    AdSoyad = "Ahmet Yimenicioğlu",
                    Email = "ahmet@otopark.com",
                    ParolaHash = "123456",
                    Rol = "User"
                },
                new Kullanici
                {
                    Id = 3,
                    AdSoyad = "Mehmet Demir",
                    Email = "mehmet@otopark.com",
                    ParolaHash = "123456",
                    Rol = "User"
                }
            );

            // 2. PARK YERLERİ (Seed Data)
            var parkYerleri = new List<ParkYeri>();
            int idCounter = 1;

            var otoparkPlanlari = new[]
            {
                new { Isim = "Bornova Alsancak", Katlar = 3, Slotlar = 15 }, // Zemin + 3 Kat (60 slot)
                new { Isim = "Kastamonu Merkez", Katlar = 0, Slotlar = 20 }, // Zemin (20 slot)
                new { Isim = "Tosya Meydan", Katlar = 2, Slotlar = 12 },     // Zemin + 2 Kat (36 slot)
                new { Isim = "Üniversite Kampüs", Katlar = 2, Slotlar = 10 }  // Zemin + 2 Kat (30 slot)
            };

            foreach (var plan in otoparkPlanlari)
            {
                for (int k = 0; k <= plan.Katlar; k++)
                {
                    string katAdi = (k == 0) ? "Zemin" : $"{k}. Kat";
                    for (int s = 1; s <= plan.Slotlar; s++)
                    {
                        parkYerleri.Add(new ParkYeri
                        {
                            Id = idCounter++,
                            Lokasyon = plan.Isim,
                            SlotNumarasi = $"{katAdi} - P{s:D2}",
                            IsActive = true
                        });
                    }
                }
            }
            modelBuilder.Entity<ParkYeri>().HasData(parkYerleri);

            // 3. ÖRNEK REZERVASYONLAR (Seed Data - 2026 Güncel)
            var now = new DateTime(2026, 9, 12, 10, 0, 0);
            modelBuilder.Entity<Rezervasyon>().HasData(
                new Rezervasyon
                {
                    Id = 1,
                    KullaniciId = 2,
                    ParkYeriId = 1, // Bornova Zemin - P01
                    BaslangicZamani = now.AddHours(-2),
                    BitisZamani = now.AddHours(2),
                    Plaka = "35AY1923",
                    Ucret = 300m,
                    UygulananIndirim = 100m,
                    OdemeDurumu = "Odendi",
                    DestekMesaji = "Girişte bariyer otomatik açıldı, teşekkürler.",
                    AdminCevabi = "Keyifli park deneyimleri dileriz!",
                    UygulamaAnket = "iyi",
                    OtoparkAnket = "iyi"
                },
                new Rezervasyon
                {
                    Id = 2,
                    KullaniciId = 3,
                    ParkYeriId = 2, // Bornova Zemin - P02
                    BaslangicZamani = now.AddHours(-1),
                    BitisZamani = now.AddHours(3),
                    Plaka = "34ABC789",
                    Ucret = 450m,
                    UygulananIndirim = 0m,
                    OdemeDurumu = "Odendi",
                    DestekMesaji = null,
                    AdminCevabi = null,
                    UygulamaAnket = "iyi",
                    OtoparkAnket = "iyi"
                },
                new Rezervasyon
                {
                    Id = 3,
                    KullaniciId = 2,
                    ParkYeriId = 61, // Kastamonu Zemin - P01
                    BaslangicZamani = now.AddDays(-2),
                    BitisZamani = now.AddDays(-2).AddHours(3),
                    Plaka = "37AY005",
                    Ucret = 350m,
                    UygulananIndirim = 100m,
                    OdemeDurumu = "Odendi",
                    DestekMesaji = "Otopark ışıklandırması çok iyiydi.",
                    AdminCevabi = "Geri bildiriminiz için teşekkürler.",
                    UygulamaAnket = "iyi",
                    OtoparkAnket = "iyi"
                }
            );
        }
    }
}