﻿using GeldeParkEt_Deneme.Data;
using GeldeParkEt_Deneme.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;

namespace GeldeParkEt_Deneme.Controllers
{
    [Authorize]
    public class ParkingController : Controller
    {
        private readonly ApplicationDbContext _context;
        private const decimal SaatlikUcret = 150m; // 2026 Güncel Saatlik Tarife (TL)
        private const decimal IlkKayitIndirimTutari = 100m; // Hoş Geldin İndirimi (TL)

        public ParkingController(ApplicationDbContext context)
        {
            _context = context;
        }

        [AllowAnonymous]
        public IActionResult Welcome()
        {
            return View();
        }

        [HttpGet]
        public async Task<IActionResult> Index(string? lokasyon = null, DateTime? Baslangic = null, DateTime? Bitis = null)
        {
            DateTime start = Baslangic ?? DateTime.Now;
            DateTime end = Bitis ?? start.AddHours(2);

            if (end <= start)
            {
                end = start.AddHours(2);
            }

            var lokasyonlar = await _context.ParkYerleri
                .Select(p => p.Lokasyon)
                .Distinct()
                .OrderBy(x => x)
                .ToListAsync();

            if (string.IsNullOrEmpty(lokasyon) || !lokasyonlar.Contains(lokasyon))
            {
                lokasyon = lokasyonlar.FirstOrDefault() ?? "Bornova Alsancak";
            }

            var parkYerleri = await _context.ParkYerleri
                .Where(p => p.Lokasyon == lokasyon)
                .OrderBy(p => p.Id)
                .ToListAsync();

            var cakisanRezervasyonlar = await _context.Rezervasyonlar
                .Include(r => r.ParkYeri)
                .Where(r => r.ParkYeri!.Lokasyon == lokasyon &&
                            r.BaslangicZamani < end &&
                            r.BitisZamani > start &&
                            r.OdemeDurumu != "IadeEdildi" &&
                            r.OdemeDurumu != "IptalEdildi")
                .ToListAsync();

            var durumListesi = parkYerleri.Select(p =>
            {
                var rez = cakisanRezervasyonlar.FirstOrDefault(r => r.ParkYeriId == p.Id);
                return new ParkYeriDurumViewModel
                {
                    Id = p.Id,
                    SlotNumarasi = p.SlotNumarasi,
                    IsActive = p.IsActive,
                    SuAnRezerveMi = rez != null,
                    DolulukBilgisi = rez != null ? $"{rez.BaslangicZamani:HH:mm} - {rez.BitisZamani:HH:mm}" : ""
                };
            }).ToList();

            var model = new ParkHaritasiViewModel
            {
                SeciliLokasyon = lokasyon,
                ParkYerleriDurum = durumListesi
            };

            // Akıllı Kat Önerisi (En çok boş yeri olan katı tespit et)
            var katGruplari = durumListesi
                .Where(x => x.IsActive)
                .GroupBy(x => x.SlotNumarasi.Contains('-') ? x.SlotNumarasi.Split('-')[0].Trim() : "Zemin")
                .OrderByDescending(g => g.Count(s => !s.SuAnRezerveMi))
                .FirstOrDefault();

            if (katGruplari != null)
            {
                model.OnerilenKat = katGruplari.Key;
            }

            ViewBag.Start = start.ToString("yyyy-MM-dd HH:mm");
            ViewBag.End = end.ToString("yyyy-MM-dd HH:mm");
            ViewBag.Lokasyonlar = lokasyonlar;
            ViewBag.SaatlikTarife = SaatlikUcret;

            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ProcessToPayment(int ParkYeriId, DateTime Baslangic, DateTime Bitis, string Plaka)
        {
            if (Bitis <= Baslangic)
            {
                Bitis = Baslangic.AddHours(2);
            }

            var parkYeri = await _context.ParkYerleri.FindAsync(ParkYeriId);
            if (parkYeri == null || !parkYeri.IsActive)
            {
                TempData["ErrorMessage"] = "Seçilen park yeri şu anda müsait değil.";
                return RedirectToAction(nameof(Index));
            }

            double toplamSaat = Math.Max(1.0, Math.Ceiling((Bitis - Baslangic).TotalHours));
            decimal hamUcret = (decimal)toplamSaat * SaatlikUcret;

            var userIdStr = User.FindFirstValue(ClaimTypes.NameIdentifier);
            bool ilkRezervasyonMu = false;

            if (int.TryParse(userIdStr, out int userId))
            {
                ilkRezervasyonMu = !await _context.Rezervasyonlar.AnyAsync(r => r.KullaniciId == userId);
            }

            decimal indirim = ilkRezervasyonMu ? Math.Min(IlkKayitIndirimTutari, hamUcret) : 0m;
            decimal odenecekTutar = Math.Max(0m, hamUcret - indirim);

            ViewBag.ParkYeri = parkYeri;
            ViewBag.ParkYeriId = ParkYeriId;
            ViewBag.Baslangic = Baslangic;
            ViewBag.Bitis = Bitis;
            ViewBag.Plaka = (Plaka ?? "").ToUpper().Trim();
            ViewBag.ToplamSaat = toplamSaat;
            ViewBag.SaatlikUcret = SaatlikUcret;
            ViewBag.HamUcret = hamUcret;
            ViewBag.Indirim = indirim;
            ViewBag.OdenecekTutar = odenecekTutar;
            ViewBag.IlkKayitIndirimi = ilkRezervasyonMu;

            return View("Payment");
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CompletePayment(int ParkYeriId, DateTime Baslangic, DateTime Bitis, string Plaka, decimal Ucret, decimal Indirim)
        {
            var userIdStr = User.FindFirstValue(ClaimTypes.NameIdentifier);
            if (string.IsNullOrEmpty(userIdStr) || !int.TryParse(userIdStr, out int userId))
            {
                return RedirectToAction("Login", "Account");
            }

            // Çakışma kontrolü (aynı anda başka biri almış mı?)
            bool cakismaVar = await _context.Rezervasyonlar.AnyAsync(r =>
                r.ParkYeriId == ParkYeriId &&
                r.BaslangicZamani < Bitis &&
                r.BitisZamani > Baslangic &&
                r.OdemeDurumu != "IadeEdildi" &&
                r.OdemeDurumu != "IptalEdildi");

            if (cakismaVar)
            {
                TempData["ErrorMessage"] = "Seçilen slot için az önce başka bir rezervasyon yapıldı. Lütfen farklı bir slot seçiniz.";
                return RedirectToAction(nameof(Index));
            }

            var yeniRezervasyon = new Rezervasyon
            {
                KullaniciId = userId,
                ParkYeriId = ParkYeriId,
                BaslangicZamani = Baslangic,
                BitisZamani = Bitis,
                Plaka = (Plaka ?? "34ABC123").ToUpper().Trim(),
                Ucret = Ucret,
                UygulananIndirim = Indirim,
                OdemeDurumu = "Odendi"
            };

            _context.Rezervasyonlar.Add(yeniRezervasyon);
            await _context.SaveChangesAsync();

            TempData["SuccessMessage"] = $"Tebrikler! #{yeniRezervasyon.Id} numaralı rezervasyonunuz ve ödemeniz başarıyla tamamlandı. Park yeriniz hazır!";
            return RedirectToAction(nameof(History));
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> SendSupportMessage(int id, string message, string UygulamaAnket, string OtoparkAnket)
        {
            var rez = await _context.Rezervasyonlar.FindAsync(id);
            if (rez != null)
            {
                rez.DestekMesaji = message;
                rez.UygulamaAnket = UygulamaAnket;
                rez.OtoparkAnket = OtoparkAnket;
                await _context.SaveChangesAsync();
                TempData["SuccessMessage"] = "Geri bildiriminiz ve anket yanıtınız başarıyla kaydedildi.";
            }
            return RedirectToAction(nameof(History));
        }

        [HttpPost]
        [Authorize(Roles = "Admin")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> HandleSupport(int id, string adminCevabi, string actionType)
        {
            var r = await _context.Rezervasyonlar.FindAsync(id);
            if (r != null)
            {
                r.AdminCevabi = adminCevabi;
                if (actionType == "Refund")
                {
                    r.Ucret = 0;
                    r.OdemeDurumu = "IadeEdildi";
                    TempData["SuccessMessage"] = $"#{id} nolu rezervasyon ücreti iade edildi ve yanıt iletildi.";
                }
                else
                {
                    TempData["SuccessMessage"] = $"#{id} nolu destek talebine yanıt iletildi.";
                }
                await _context.SaveChangesAsync();
            }
            return RedirectToAction(nameof(AdminPanel));
        }

        [HttpGet]
        public async Task<IActionResult> History()
        {
            var userIdStr = User.FindFirstValue(ClaimTypes.NameIdentifier);
            if (string.IsNullOrEmpty(userIdStr) || !int.TryParse(userIdStr, out int userId))
            {
                return RedirectToAction("Login", "Account");
            }

            var reservations = await _context.Rezervasyonlar
                .Include(r => r.ParkYeri)
                .Where(r => r.KullaniciId == userId)
                .OrderByDescending(r => r.Id)
                .ToListAsync();

            return View(reservations);
        }

        [Authorize(Roles = "Admin")]
        [HttpGet]
        public async Task<IActionResult> AdminPanel()
        {
            var otoparklar = await _context.ParkYerleri
                .GroupBy(p => p.Lokasyon)
                .Select(g => new
                {
                    Lok = g.Key,
                    Aktif = g.Any(x => x.IsActive)
                })
                .ToListAsync();

            ViewBag.OtoparkDurumlari = otoparklar.ToDictionary(x => x.Lok, x => x.Aktif);

            var tumRezervasyonlar = await _context.Rezervasyonlar
                .Include(r => r.Kullanici)
                .Include(r => r.ParkYeri)
                .OrderByDescending(r => r.Id)
                .ToListAsync();

            return View(tumRezervasyonlar);
        }
    }
}