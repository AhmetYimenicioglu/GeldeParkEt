﻿using GeldeParkEt_Deneme.Data;
using GeldeParkEt_Deneme.Models;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;

namespace GeldeParkEt_Deneme.Controllers
{
    public class AccountController : Controller
    {
        private readonly ApplicationDbContext _context;

        public AccountController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public IActionResult Register()
        {
            if (User.Identity?.IsAuthenticated == true)
            {
                return RedirectToAction("Welcome", "Parking");
            }
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Register(Kullanici model)
        {
            if (ModelState.IsValid)
            {
                if (string.IsNullOrWhiteSpace(model.Email))
                {
                    ModelState.AddModelError("Email", "Lütfen geçerli bir e-posta adresi giriniz.");
                    return View(model);
                }

                string emailNorm = model.Email.Trim().ToLower();

                if (await _context.Kullanicilar.AnyAsync(u => u.Email.ToLower() == emailNorm))
                {
                    ModelState.AddModelError("Email", "Bu e-posta adresi ile zaten kayıtlı bir hesap bulunmaktadır.");
                    return View(model);
                }

                var newUser = new Kullanici
                {
                    AdSoyad = model.AdSoyad.Trim(),
                    Email = emailNorm,
                    ParolaHash = model.ParolaHash,
                    Rol = emailNorm.EndsWith("@otopark.com") && emailNorm.StartsWith("admin") ? "Admin" : "User"
                };

                _context.Add(newUser);
                await _context.SaveChangesAsync();

                TempData["SuccessMessage"] = "Hesabınız başarıyla oluşturuldu! Şimdi giriş yapabilirsiniz.";
                return RedirectToAction("Login");
            }

            return View(model);
        }

        [HttpGet]
        public IActionResult Login(string? returnUrl = null)
        {
            if (User.Identity?.IsAuthenticated == true)
            {
                return RedirectToAction("Welcome", "Parking");
            }

            // Güvenlik CAPTCHA: Rastgele iki sayı üret ve oturumda sakla
            Random rnd = new Random();
            int s1 = rnd.Next(2, 9);
            int s2 = rnd.Next(1, 9);
            HttpContext.Session.SetInt32("CaptchaSonuc", s1 + s2);

            ViewBag.CaptchaSoru = $"{s1} + {s2} = ?";
            ViewBag.ReturnUrl = returnUrl;
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Login(string email, string parola, int captchaInput, string? returnUrl = null)
        {
            // CAPTCHA Kontrolü
            int? dogruSonuc = HttpContext.Session.GetInt32("CaptchaSonuc");
            if (captchaInput != dogruSonuc)
            {
                ModelState.AddModelError(string.Empty, "Güvenlik doğrulaması (CAPTCHA) hatalı. Lütfen işlemi tekrar deneyin.");
                return YenidenLoginYukle(returnUrl);
            }

            if (string.IsNullOrWhiteSpace(email) || string.IsNullOrWhiteSpace(parola))
            {
                ModelState.AddModelError(string.Empty, "E-posta ve parola alanları zorunludur.");
                return YenidenLoginYukle(returnUrl);
            }

            string emailNorm = email.Trim().ToLower();
            var user = await _context.Kullanicilar.FirstOrDefaultAsync(u => u.Email.ToLower() == emailNorm);

            if (user != null && user.ParolaHash == parola)
            {
                var claims = new List<Claim>
                {
                    new Claim(ClaimTypes.NameIdentifier, user.Id.ToString()),
                    new Claim(ClaimTypes.Name, user.AdSoyad),
                    new Claim(ClaimTypes.Email, user.Email),
                    new Claim(ClaimTypes.Role, user.Rol)
                };

                var claimsIdentity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
                var authProperties = new AuthenticationProperties
                {
                    IsPersistent = true,
                    ExpiresUtc = DateTimeOffset.UtcNow.AddHours(4)
                };

                await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, new ClaimsPrincipal(claimsIdentity), authProperties);

                if (!string.IsNullOrEmpty(returnUrl) && Url.IsLocalUrl(returnUrl))
                {
                    return Redirect(returnUrl);
                }

                return RedirectToAction("Welcome", "Parking");
            }

            ModelState.AddModelError(string.Empty, "Geçersiz e-posta veya parola. Lütfen bilgilerinizi kontrol ediniz.");
            return YenidenLoginYukle(returnUrl);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Logout()
        {
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            return RedirectToAction("Login", "Account");
        }

        [HttpGet]
        public IActionResult AccessDenied()
        {
            return View();
        }

        private IActionResult YenidenLoginYukle(string? returnUrl)
        {
            Random rnd = new Random();
            int s1 = rnd.Next(2, 9);
            int s2 = rnd.Next(1, 9);
            HttpContext.Session.SetInt32("CaptchaSonuc", s1 + s2);
            ViewBag.CaptchaSoru = $"{s1} + {s2} = ?";
            ViewBag.ReturnUrl = returnUrl;
            return View("Login");
        }
    }
}