﻿using GeldeParkEt_Deneme.Data;
using GeldeParkEt_Deneme.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace GeldeParkEt_Deneme.Controllers
{
    [Authorize(Roles = "Admin")]
    public class AdminController : Controller
    {
        private readonly ApplicationDbContext _context;

        public AdminController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<IActionResult> Dashboard()
        {
            ViewBag.ToplamParkYeri = await _context.ParkYerleri.CountAsync();
            ViewBag.ToplamRezervasyon = await _context.Rezervasyonlar.CountAsync();
            ViewBag.ToplamKullanici = await _context.Kullanicilar.CountAsync();
            ViewBag.ToplamGelir = await _context.Rezervasyonlar
                .Where(r => r.OdemeDurumu == "Odendi")
                .SumAsync(r => (decimal?)r.Ucret) ?? 0m;
            ViewBag.AktifRezervasyon = await _context.Rezervasyonlar
                .CountAsync(r => r.BaslangicZamani <= DateTime.Now && r.BitisZamani >= DateTime.Now && r.OdemeDurumu == "Odendi");

            return View();
        }

        [HttpGet]
        public async Task<IActionResult> AllReservations()
        {
            var reservations = await _context.Rezervasyonlar
                .Include(r => r.Kullanici)
                .Include(r => r.ParkYeri)
                .OrderByDescending(r => r.Id)
                .ToListAsync();

            return View(reservations);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CancelReservation(int id)
        {
            var rez = await _context.Rezervasyonlar.FindAsync(id);
            if (rez != null)
            {
                rez.OdemeDurumu = "IptalEdildi";
                rez.Ucret = 0;
                await _context.SaveChangesAsync();
                TempData["SuccessMessage"] = $"#{id} numaralı rezervasyon başarıyla iptal edildi ve ücret sıfırlandı.";
            }
            else
            {
                TempData["ErrorMessage"] = "İptal edilecek rezervasyon bulunamadı.";
            }

            return RedirectToAction(nameof(AllReservations));
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ToggleStatus(string lokasyonAdi)
        {
            var yerler = await _context.ParkYerleri.Where(p => p.Lokasyon == lokasyonAdi).ToListAsync();
            if (yerler.Count > 0)
            {
                bool suAnkiDurum = yerler[0].IsActive;
                foreach (var yer in yerler)
                {
                    yer.IsActive = !suAnkiDurum;
                }
                await _context.SaveChangesAsync();
                TempData["SuccessMessage"] = $"{lokasyonAdi} otoparkı {(suAnkiDurum ? "KAPATILDI" : "AÇILDI")}.";
            }
            return RedirectToAction("AdminPanel", "Parking");
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteLocation(string lokasyonAdi)
        {
            var slotIdleri = await _context.ParkYerleri.Where(p => p.Lokasyon == lokasyonAdi).Select(p => p.Id).ToListAsync();
            var bagliRezervasyonlar = await _context.Rezervasyonlar.Where(r => slotIdleri.Contains(r.ParkYeriId)).ToListAsync();

            _context.Rezervasyonlar.RemoveRange(bagliRezervasyonlar);
            var silinecekYerler = await _context.ParkYerleri.Where(p => p.Lokasyon == lokasyonAdi).ToListAsync();
            _context.ParkYerleri.RemoveRange(silinecekYerler);

            await _context.SaveChangesAsync();
            TempData["SuccessMessage"] = $"{lokasyonAdi} lokasyonu ve tüm bağlı verileri başarıyla silindi.";
            return RedirectToAction("AdminPanel", "Parking");
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ResetSystem()
        {
            _context.Rezervasyonlar.RemoveRange(_context.Rezervasyonlar);
            _context.ParkYerleri.RemoveRange(_context.ParkYerleri);
            _context.Kullanicilar.RemoveRange(_context.Kullanicilar.Where(u => u.Rol != "Admin"));
            await _context.SaveChangesAsync();
            TempData["SuccessMessage"] = "Sistem sıfırlandı (Yönetici hesabı korundu).";
            return RedirectToAction("AdminPanel", "Parking");
        }

        [HttpGet]
        public IActionResult CreateLocation()
        {
            return View(new OtoparkEkleViewModel());
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CreateLocation(OtoparkEkleViewModel model)
        {
            if (ModelState.IsValid)
            {
                if (await _context.ParkYerleri.AnyAsync(p => p.Lokasyon.ToLower() == model.OtoparkAdi.Trim().ToLower()))
                {
                    ModelState.AddModelError("OtoparkAdi", "Bu isimde bir otopark zaten mevcut.");
                    return View(model);
                }

                var yeniParkYerleri = new List<ParkYeri>();
                for (int i = 0; i <= model.KatSayisi; i++)
                {
                    string katIsmi = (i == 0) ? "Zemin" : $"{i}. Kat";
                    for (int j = 1; j <= model.KatBasiSlot; j++)
                    {
                        yeniParkYerleri.Add(new ParkYeri
                        {
                            Lokasyon = model.OtoparkAdi.Trim(),
                            SlotNumarasi = $"{katIsmi} - P{j:D2}",
                            IsActive = true
                        });
                    }
                }

                await _context.ParkYerleri.AddRangeAsync(yeniParkYerleri);
                await _context.SaveChangesAsync();

                TempData["SuccessMessage"] = $"{model.OtoparkAdi} otoparkı ({yeniParkYerleri.Count} slot) başarıyla inşa edildi ve sisteme eklendi!";
                return RedirectToAction("AdminPanel", "Parking");
            }

            return View(model);
        }
    }
}