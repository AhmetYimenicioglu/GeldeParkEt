﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace GeldeParkEt_Deneme.Migrations
{
    /// <inheritdoc />
    public partial class AddDiscountAndFineFields : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<decimal>(
                name: "UygulananIndirim",
                table: "Rezervasyonlar",
                type: "decimal(18,2)",
                nullable: false,
                defaultValue: 0m);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "UygulananIndirim",
                table: "Rezervasyonlar");
        }
    }
}
